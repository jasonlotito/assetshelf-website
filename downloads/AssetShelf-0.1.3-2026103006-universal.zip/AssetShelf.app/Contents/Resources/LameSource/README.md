# Bundled LAME 4.0

Upstream: https://lame.sourceforge.io/ and https://downloads.sourceforge.net/project/lame/lame/4.0/lame-4.0.tar.gz

Archive SHA-256: `3df5124d5ad3a98312ffd7ba6a9b36230e4f8a3e66d3ce0f425e336c32d216eb`

The C sources and headers are unmodified from the official release. This package selects the libmp3lame encoder and decoder-disabled interface stubs. It does not build the command-line frontend, mpg123 decoder, optional assembly, or optional SIMD code. macOS Core Audio decodes input. `config.h` was generated on 64-bit macOS with `./configure --disable-frontend --disable-decoder --disable-nasm --disable-shared --enable-static`; its platform definitions also apply to x86_64. The config explicitly undefines DEBUG to disable upstream per-frame diagnostic dumps in app Debug builds. SwiftPM controls the actual **dynamic** library product regardless of the configure link flags. The only additions are Package.swift, the module map, configuration, and packaging documentation/scripts.

Both the app and SwiftPM MCP executable link the separate CLame dynamic library. Xcode embeds it in the app's Frameworks directory. No Homebrew path, external encoder executable, or runtime download is used. The app also ships the complete upstream source archive, license, configuration and standalone rebuild package instructions in `Contents/Resources/LameSource`. Keep that directory and the encoder library with any app distribution. For a separately distributed SwiftPM MCP binary, include its CLame dynamic library and this source/license directory alongside it, preserving its relative library load paths.

Run `swift build --package-path Support/Lame -c release` to rebuild the standalone encoder. LAME is licensed under LGPL version 2 or later; see COPYING and upstream LICENSE. Modifications to the bundled library can be rebuilt/replaced independently. If changing a signed app, re-sign the modified copy as required by macOS. Reverse engineering for debugging modifications to this library is permitted. No LAME source changes were made.

To reconstruct the exact standalone package from these resources, run `python3 rebuild.py /absolute/path/to/new-build-folder`, then `swift build --package-path /absolute/path/to/new-build-folder -c release`. The folder must not exist. To use modified source, edit the reconstructed C source before building. Xcode may wrap the dynamic product in CLame.framework rather than a bare dylib; preserve the replaced library's install name (`otool -D`) and relative placement when replacing it.
