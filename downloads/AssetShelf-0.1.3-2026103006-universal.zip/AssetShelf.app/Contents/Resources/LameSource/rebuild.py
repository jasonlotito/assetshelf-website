#!/usr/bin/env python3
"""Reconstruct the bundled encoder package from the shipped upstream source."""
from pathlib import Path
import hashlib
import shutil
import sys
import tarfile
import tempfile

here = Path(__file__).resolve().parent
archive = here / "lame-4.0.tar.gz"
assert hashlib.sha256(archive.read_bytes()).hexdigest() == "3df5124d5ad3a98312ffd7ba6a9b36230e4f8a3e66d3ce0f425e336c32d216eb"
root = Path(sys.argv[1]).resolve()
root.mkdir(exist_ok=False)
with tempfile.TemporaryDirectory() as temp:
    with tarfile.open(archive) as source:
        source.extractall(temp, filter="data")
    upstream = Path(temp) / "lame-4.0"
    target = root / "Sources/CLame"
    (target / "include").mkdir(parents=True)
    for file in (upstream / "libmp3lame").iterdir():
        if file.suffix in (".c", ".h"):
            shutil.copy2(file, target / file.name)
    for name in ("vector/lame_intrin.h",):
        (target / name).parent.mkdir(exist_ok=True)
        shutil.copy2(upstream / "libmp3lame" / name, target / name)
    (target / "mpglib").mkdir()
    shutil.copy2(upstream / "mpglib/mpglib.h", target / "mpglib/mpglib.h")
    shutil.copy2(upstream / "include/lame.h", target / "include/lame.h")
    (target / "include/module.modulemap").write_text('module CLame {\n    header "lame.h"\n    export *\n}\n')
    shutil.copy2(here / "config.h", target / "config.h")
    shutil.copy2(here / "Package.swift.template", root / "Package.swift")
    for name in ("COPYING", "LICENSE"):
        shutil.copy2(here / name, root / name)
print("Reconstructed encoder package:", root)
